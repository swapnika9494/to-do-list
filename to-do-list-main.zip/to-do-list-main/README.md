# to-do-list
A simple task management website built with HTML, CSS, and JavaScript. It enables users to create, edit, delete, and view tasks, helping them stay organized with daily tasks or shopping lists. This project showcases fundamental web development skills and emphasizes practical, everyday utility.
